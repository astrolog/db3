package stattrade.calendar.model;

/**
 * Model zdarzenia kalendarza ekonomicznego.
 * Odpowiada kolumnom tabeli [dbo].[event3].
 */
public class CalendarEvent {

    public String source;      // "FF", "IN", "FX"
    public String datetime;    // "yyyy-MM-dd HH:mm"
    public String cur;         // waluta np. "USD"
    public String event;       // nazwa zdarzenia
    public String period;      // np. "Jan", "Q1"
    public String timeframe;   // "MoM", "YoY", "QoQ", "day", ""
    public String act;         // actual value lub "null"
    public String fore;        // forecast value lub "null"
    public String pre;         // previous value lub "null"
    public String type;        // "K", "M", "B", "%", ""
    public String impact;      // "high", "medium", "low", "holiday"
    public String is_better;   // "better", "worse", "actual"
    public String rev;         // revised previous lub "null"

    public CalendarEvent() {
        // domyślne wartości null dla SQL
        this.act      = "null";
        this.fore     = "null";
        this.pre      = "null";
        this.rev      = "null";
        this.type     = "";
        this.period   = "";
        this.timeframe = "";
        this.is_better = "";
        this.impact    = "";
    }

    /**
     * Buduje string SQL EXECUTE dla procedury sp_event3.
     * Zgodne z oryginalnym load3.js.
     */
    public String toSqlExec(String db) {
        return String.format(
            "EXECUTE [%s].[dbo].[sp_event3] " +
            "@source='%s',@datetime='%s',@cur='%s',@event='%s'," +
            "@period='%s',@timeframe='%s'," +
            "@act=%s,@fore=%s,@pre=%s," +
            "@type='%s',@impact='%s',@is_better='%s',@rev=%s",
            db, source, datetime, cur, event,
            period, timeframe,
            act, fore, pre,
            type, impact, is_better, rev
        );
    }

    @Override
    public String toString() {
        return source + " | " + datetime + " | " + cur + " | " + event +
               " | act=" + act + " fore=" + fore + " pre=" + pre;
    }
}
