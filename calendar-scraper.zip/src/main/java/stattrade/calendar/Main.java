package stattrade.calendar;

import stattrade.calendar.db.Database;
import stattrade.calendar.scraper.*;

import java.util.logging.*;

/**
 * Główny punkt wejścia projektu calendar-scraper.
 *
 * Użycie:
 *   java -jar calendar-scraper.jar <src> [mode] [headless]
 *
 * Parametry:
 *   src      = forexfactory | investing | fxstreet
 *   mode     = now | next | today (opcjonalny, domyślnie brak = pełny backfill)
 *   headless = true | false (opcjonalny, domyślnie true)
 *
 * Przykłady:
 *   java -jar calendar-scraper.jar forexfactory now
 *   java -jar calendar-scraper.jar investing next
 *   java -jar calendar-scraper.jar fxstreet now false   (widoczna przeglądarka)
 *   java -jar calendar-scraper.jar forexfactory
 *
 * Odpowiedniki trybów z load3.js:
 *   forexfactory_now   → forexfactory now
 *   forexfactory_next  → forexfactory next
 *   investing_now      → investing now
 *   investing_next     → investing next
 *   fxstreet_now       → fxstreet now
 *   fxstreet_next      → fxstreet next
 */
public class Main {

    // ── Konfiguracja bazy ──────────────────────────────────────────
    private static final String DB_SERVER   = "127.0.0.1";
    private static final int    DB_PORT     = 1433;
    private static final String DB_NAME     = "db2";
    private static final String DB_USER     = "sa";
    private static final String DB_PASSWORD = "astrolog";
    // ───────────────────────────────────────────────────────────────

    public static void main(String[] args) {
        setupLogging();

        if (args.length < 1) {
            printUsage();
            System.exit(1);
        }

        String src      = args[0].toLowerCase().trim();
        String mode     = args.length > 1 ? args[1].toLowerCase().trim() : "";
        boolean headless = args.length > 2 ? Boolean.parseBoolean(args[2]) : true;

        Logger log = Logger.getLogger(Main.class.getName());
        log.info("Uruchamiam: src=" + src + " mode=" + mode + " headless=" + headless);

        Database db = null;
        try {
            db = new Database(DB_SERVER, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD);

            switch (src) {
                case "forexfactory", "ff" -> {
                    new ForexFactoryScraper(db).run(mode);
                }
                case "investing", "in" -> {
                    new InvestingScraper(db).run(mode, headless);
                }
                case "fxstreet", "fx" -> {
                    new FxStreetScraper(db).run(mode, headless);
                }
                default -> {
                    System.err.println("Nieznane źródło: " + src);
                    printUsage();
                    System.exit(1);
                }
            }

            log.info("Zakończono pomyślnie.");

        } catch (Exception e) {
            Logger.getLogger(Main.class.getName()).severe("Błąd krytyczny: " + e.getMessage());
            e.printStackTrace();
            System.exit(2);
        } finally {
            if (db != null) db.close();
        }
    }

    private static void printUsage() {
        System.out.println("""
            Użycie: java -jar calendar-scraper.jar <src> [mode] [headless]
            
            src:      forexfactory (ff) | investing (in) | fxstreet (fx)
            mode:     now | next | today | (brak = backfill)
            headless: true | false  (domyślnie: true)
            
            Przykłady:
              java -jar calendar-scraper.jar forexfactory now
              java -jar calendar-scraper.jar investing next
              java -jar calendar-scraper.jar fxstreet now false
            """);
    }

    private static void setupLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.INFO);
        for (Handler h : root.getHandlers()) {
            h.setFormatter(new SimpleFormatter() {
                @Override
                public String format(LogRecord r) {
                    return String.format("[%1$tF %1$tT] [%2$s] %3$s%n",
                        new java.util.Date(r.getMillis()),
                        r.getLevel(),
                        r.getMessage());
                }
            });
        }
    }
}
