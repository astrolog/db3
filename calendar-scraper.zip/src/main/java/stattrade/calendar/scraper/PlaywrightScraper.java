package stattrade.calendar.scraper;

import com.microsoft.playwright.*;
import stattrade.calendar.db.Database;

import java.util.logging.Logger;

/**
 * Bazowa klasa dla scraperów używających Playwright.
 * Zarządza cyklem życia przeglądarki.
 */
public abstract class PlaywrightScraper implements AutoCloseable {

    protected static final Logger log = Logger.getLogger(PlaywrightScraper.class.getName());

    protected final Database db;
    protected Playwright playwright;
    protected Browser browser;
    protected BrowserContext context;
    protected Page page;

    protected PlaywrightScraper(Database db) {
        this.db = db;
    }

    /**
     * Inicjalizuje Playwright + Chromium.
     * headless=true domyślnie, można zmienić przez setHeadless(false) przed uruchomieniem.
     */
    protected void initBrowser(boolean headless) {
        playwright = Playwright.create();
        browser = playwright.chromium().launch(
            new BrowserType.LaunchOptions()
                .setHeadless(headless)
                .setArgs(java.util.List.of(
                    "--no-sandbox",
                    "--disable-blink-features=AutomationControlled"
                ))
        );
        context = browser.newContext(
            new Browser.NewContextOptions()
                .setViewportSize(1280, 900)
                .setLocale("en-US")
                .setTimezoneId("UTC")
                .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                              "AppleWebKit/537.36 (KHTML, like Gecko) " +
                              "Chrome/124.0.0.0 Safari/537.36")
        );
        page = context.newPage();

        // blokuj reklamy/trackingi → szybsze ładowanie
        page.route("**/{ads,analytics,tracking,gtm,doubleclick}**", route -> route.abort());
        page.route("**/*.{png,jpg,gif,webp,woff,woff2}", route -> route.abort());

        log.info("Playwright/Chromium zainicjalizowany (headless=" + headless + ")");
    }

    /** Czeka na element, zwraca null jeśli nie pojawi się w czasie timeout ms */
    protected Locator waitFor(String selector, int timeoutMs) {
        try {
            Locator loc = page.locator(selector);
            loc.first().waitFor(new Locator.WaitForOptions()
                .setTimeout(timeoutMs)
                .setState(WaitForSelectorState.VISIBLE));
            return loc;
        } catch (Exception e) {
            log.warning("Timeout czekając na: " + selector);
            return null;
        }
    }

    /** Klika element jeśli istnieje, ignoruje błąd jeśli nie ma */
    protected void clickIfPresent(String selector) {
        try {
            Locator loc = page.locator(selector).first();
            if (loc.isVisible()) loc.click();
        } catch (Exception ignored) {}
    }

    /** Bezpieczne getText — zwraca "" jeśli element nie istnieje */
    protected String safeText(Locator loc) {
        try { return loc.textContent().trim(); }
        catch (Exception e) { return ""; }
    }

    /** Bezpieczne innerHTML */
    protected String safeHtml(Locator loc) {
        try { return loc.innerHTML(); }
        catch (Exception e) { return ""; }
    }

    @Override
    public void close() {
        try { if (context != null) context.close(); } catch (Exception ignored) {}
        try { if (browser != null) browser.close(); } catch (Exception ignored) {}
        try { if (playwright != null) playwright.close(); } catch (Exception ignored) {}
        log.info("Playwright zamknięty.");
    }
}
