package stattrade.calendar.scraper;

import com.microsoft.playwright.*;
import stattrade.calendar.db.Database;
import stattrade.calendar.model.CalendarEvent;
import stattrade.calendar.util.ValueParser;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

/**
 * Scraper FXStreet — używa Playwright.
 *
 * URL: https://www.fxstreet.com/economic-calendar
 * source = "FX"
 *
 * FXStreet renderuje tabelę po JS i używa klas fxs_c_*.
 * Scraper iteruje po dniach (click Next Day lub ustawia datę przez URL/filtr).
 */
public class FxStreetScraper extends PlaywrightScraper {

    private static final String SOURCE = "FX";
    private static final String BASE_URL = "https://www.fxstreet.com/economic-calendar";
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public FxStreetScraper(Database db) {
        super(db);
    }

    public void run(String mode, boolean headless) {
        log.info("FXStreet start, mode=" + mode);
        initBrowser(headless);

        try {
            LocalDate startDate = resolveStartDate(mode);
            LocalDate endDate   = LocalDate.now().plusDays(1);
            int maxIter = resolveMaxIter(mode, startDate, endDate);

            log.info("Start: " + startDate + " | iter max: " + maxIter);

            page.navigate(BASE_URL);
            page.waitForLoadState();
            page.waitForTimeout(1500);

            // zamknij cookie/popupy
            clickIfPresent(".fxs_close_cookies");
            clickIfPresent("button[id='onesignal-popover-cancel-button']");
            page.waitForTimeout(500);

            LocalDate current = startDate;
            int iter = 0;

            while (iter < maxIter && !current.isAfter(endDate)) {
                log.info("Przetwarzam: " + current + " (iter " + iter + ")");
                navigateToDate(current);
                List<CalendarEvent> events = extractEvents(current);

                if (!events.isEmpty()) {
                    db.deleteDate(current, SOURCE);
                    for (CalendarEvent ev : events) {
                        db.saveEvent(ev);
                        log.info("FX zapisano: " + ev);
                    }
                }

                current = current.plusDays(1);
                iter++;
                page.waitForTimeout(2000);
            }

            db.runPostImport();
            log.info("FXStreet zakończony. Przetworzono " + iter + " dni.");

        } catch (Exception e) {
            log.severe("Błąd FXStreet: " + e.getMessage());
        } finally {
            close();
        }
    }

    private LocalDate resolveStartDate(String mode) {
        LocalDate now = LocalDate.now();
        return switch (mode) {
            case "now"  -> {
                LocalDate d = db.getLastDbDate(SOURCE);
                yield (d != null) ? d : now;
            }
            case "next" -> {
                LocalDate d = db.getLastDbDateNoAct(SOURCE);
                yield (d != null) ? d.plusDays(1) : now;
            }
            default -> LocalDate.of(2007, 1, 1);
        };
    }

    private int resolveMaxIter(String mode, LocalDate start, LocalDate end) {
        long diff = java.time.temporal.ChronoUnit.DAYS.between(start, end);
        return switch (mode) {
            case "now"  -> (int) Math.min(diff + 3, 20);
            case "next" -> (int) Math.min(diff + 14, 30);
            default     -> 3000;
        };
    }

    /**
     * Nawiguje do danego dnia.
     * FXStreet pozwala filtrować przez URL parameter lub przez UI date picker.
     * Używamy URL: https://www.fxstreet.com/economic-calendar?startDate=2025-01-15
     */
    private void navigateToDate(LocalDate date) {
        String url = BASE_URL + "?startDate=" + date.format(DATE_FMT) +
                                "&endDate="   + date.format(DATE_FMT);
        page.navigate(url);
        page.waitForLoadState();

        // czekaj na załadowanie wierszy
        waitFor(".fxs_c_row", 8000);
        page.waitForTimeout(800);
    }

    private List<CalendarEvent> extractEvents(LocalDate date) {
        List<CalendarEvent> events = new ArrayList<>();
        String dateStr = date.format(DATE_FMT);

        List<ElementHandle> rows = page.querySelectorAll(".fxs_c_row");
        if (rows.isEmpty()) {
            log.info("Brak wierszy dla " + dateStr);
            return events;
        }

        String lastTime = "00:00";

        for (ElementHandle row : rows) {
            try {
                // pomiń wiersze-etykiety (label separator)
                String rowHtml = row.innerHTML();
                if (rowHtml.contains("fxs_c_label")) continue;

                CalendarEvent ev = extractRow(row, dateStr, lastTime);
                if (ev != null) {
                    lastTime = ev.datetime.substring(11); // aktualizuj ostatni znany czas
                    events.add(ev);
                }
            } catch (Exception e) {
                log.warning("Błąd parsowania wiersza FX: " + e.getMessage());
            }
        }

        return events;
    }

    private CalendarEvent extractRow(ElementHandle row, String dateStr, String lastTime) {
        // czas
        ElementHandle timeEl = row.querySelector(".fxs_c_time");
        String timeText = timeEl != null ? timeEl.textContent().trim() : "";
        boolean isAllDay = timeText.contains("24h") || timeText.contains("N/A") ||
                           timeText.isEmpty();
        if (isAllDay) timeText = "00:00";
        if (!timeText.isEmpty() && !timeText.equals("00:00")) lastTime = timeText;
        else if (timeText.isEmpty()) timeText = lastTime;

        // waluta
        ElementHandle curEl = row.querySelector(".fxs_c_currency");
        String cur = curEl != null ? curEl.textContent().trim().replace(" ", "") : "";

        // impact — z klasy HTML
        ElementHandle impEl = row.querySelector(".fxs_c_impact");
        String impHtml = impEl != null ? impEl.innerHTML().toLowerCase() : "";
        String impact = parseImpact(impHtml);

        // nazwa
        ElementHandle nameEl = row.querySelector(".fxs_c_name");
        String rawEvent = nameEl != null ? nameEl.textContent().trim() : "";
        if (rawEvent.isEmpty()) return null;

        // actual
        ElementHandle actEl = row.querySelector(".fxs_c_actual");
        String actText = actEl != null ? actEl.textContent().trim() : "";
        String actHtml = actEl != null ? actEl.innerHTML() : "";

        // forecast
        ElementHandle foreEl = row.querySelector(".fxs_c_consensus");
        String foreText = foreEl != null ? foreEl.textContent().trim() : "";

        // previous
        ElementHandle prevEl = row.querySelector(".fxs_c_previous");
        String prevText = prevEl != null ? prevEl.textContent().trim() : "";
        String prevHtml = prevEl != null ? prevEl.innerHTML() : "";

        CalendarEvent ev = new CalendarEvent();
        ev.source   = SOURCE;
        ev.datetime = dateStr + " " + timeText;
        ev.cur      = cur;
        ev.impact   = impact;

        ev.timeframe = ValueParser.extractTimeframe(rawEvent);
        ev.period    = ValueParser.extractPeriod(rawEvent);
        ev.event     = ValueParser.cleanEventName(rawEvent);

        ev.act  = cleanVal(actText);
        ev.fore = cleanVal(foreText);
        ev.pre  = cleanVal(prevText);
        ev.type = ValueParser.getType(actText.isEmpty() ? prevText : actText);

        // is_better
        if (actHtml.contains("negative") || actHtml.contains("worse"))   ev.is_better = "worse";
        else if (actHtml.contains("positive") || actHtml.contains("better")) ev.is_better = "better";
        else ev.is_better = "actual";

        // revised
        if (prevHtml.contains("Revised from ")) {
            String rev = prevHtml.split("Revised from ")[1].split("<")[0];
            ev.rev = cleanVal(ValueParser.getValue(rev));
        }

        if (isAllDay) ev.timeframe = "day";

        return ev;
    }

    private String parseImpact(String html) {
        if (html == null) return "";
        if (html.contains("high"))   return "high";
        if (html.contains("medium")) return "medium";
        if (html.contains("low"))    return "low";
        return "";
    }

    private String cleanVal(String raw) {
        String v = ValueParser.getValue(raw, 0);
        return (v == null || v.isEmpty()) ? "null" : v;
    }
}
