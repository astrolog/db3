package stattrade.calendar.scraper;

import stattrade.calendar.db.Database;
import stattrade.calendar.model.CalendarEvent;
import stattrade.calendar.util.ValueParser;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.InputStream;
import java.net.URI;
import java.net.http.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

/**
 * Scraper ForexFactory — używa oficjalnego XML feeda.
 * Nie wymaga przeglądarki. Stabilny, bo FF sam dostarcza XML.
 *
 * URL bieżącego tygodnia: https://nfs.faireconomy.media/ff_calendar_thisweek.xml
 * URL następnego tygodnia: https://nfs.faireconomy.media/ff_calendar_nextweek.xml
 *
 * source = "FF"
 */
public class ForexFactoryScraper {

    private static final Logger log = Logger.getLogger(ForexFactoryScraper.class.getName());

    private static final String URL_THIS_WEEK = "https://nfs.faireconomy.media/ff_calendar_thisweek.xml";
    private static final String URL_NEXT_WEEK = "https://nfs.faireconomy.media/ff_calendar_nextweek.xml";
    private static final String SOURCE = "FF";

    private final Database db;
    private final HttpClient http;

    public ForexFactoryScraper(Database db) {
        this.db = db;
        this.http = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.ALWAYS)
            .build();
    }

    /**
     * Tryb: _now / _today → bieżący + następny tydzień (nadchodzące zdarzenia)
     * Tryb: _next         → tylko następny tydzień
     * Tryb: domyślny      → tylko bieżący tydzień
     */
    public void run(String mode) {
        log.info("ForexFactory start, mode=" + mode);

        if ("now".equals(mode) || "today".equals(mode)) {
            fetchAndSave(URL_THIS_WEEK);
            fetchAndSave(URL_NEXT_WEEK);
        } else if ("next".equals(mode)) {
            fetchAndSave(URL_NEXT_WEEK);
        } else {
            fetchAndSave(URL_THIS_WEEK);
        }

        db.runPostImport();
        log.info("ForexFactory zakończony.");
    }

    private void fetchAndSave(String url) {
        log.info("Pobieranie: " + url);
        try {
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("User-Agent", "Mozilla/5.0")
                .header("Accept", "application/xml, text/xml, */*")
                .GET()
                .build();

            HttpResponse<InputStream> resp = http.send(req, HttpResponse.BodyHandlers.ofInputStream());

            if (resp.statusCode() != 200) {
                log.warning("HTTP " + resp.statusCode() + " dla " + url);
                return;
            }

            List<CalendarEvent> events = parseXml(resp.body());
            log.info("Sparsowano " + events.size() + " zdarzeń z " + url);

            // Grupuj po dacie i zapisuj (z usunięciem przed zapisem)
            Map<LocalDate, List<CalendarEvent>> byDate = new LinkedHashMap<>();
            for (CalendarEvent ev : events) {
                LocalDate d = LocalDate.parse(ev.datetime.substring(0, 10));
                byDate.computeIfAbsent(d, k -> new ArrayList<>()).add(ev);
            }

            for (Map.Entry<LocalDate, List<CalendarEvent>> entry : byDate.entrySet()) {
                db.deleteDate(entry.getKey(), SOURCE);
                for (CalendarEvent ev : entry.getValue()) {
                    db.saveEvent(ev);
                    log.info("Zapisano: " + ev);
                }
            }

        } catch (Exception e) {
            log.severe("Błąd fetchAndSave " + url + ": " + e.getMessage());
        }
    }

    /**
     * Parsuje XML feed ForexFactory.
     *
     * Struktura XML:
     * <weeklyevents>
     *   <event>
     *     <title>...</title>
     *     <country>...</country>
     *     <date>...</date>   → "01-20-2025"  (MM-dd-yyyy, Eastern Time)
     *     <time>...</time>   → "8:30am" lub "Tentative" lub "All Day"
     *     <impact>...</impact>  → "High", "Medium", "Low", "Holiday", "Non-Economic"
     *     <forecast>...</forecast>
     *     <previous>...</previous>
     *     <actual>...</actual>  (puste gdy brak danych)
     *     <revised>...</revised>
     *   </event>
     * </weeklyevents>
     *
     * UWAGA: czas w XML jest w Eastern Time — konwertujemy do UTC.
     */
    private List<CalendarEvent> parseXml(InputStream is) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // zabezpieczenie XXE
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(is);
        doc.getDocumentElement().normalize();

        NodeList nodes = doc.getElementsByTagName("event");
        List<CalendarEvent> results = new ArrayList<>();

        DateTimeFormatter inputDateFmt = DateTimeFormatter.ofPattern("MM-dd-yyyy", Locale.US);
        DateTimeFormatter outputDateFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE) continue;
            Element el = (Element) node;

            String title    = getText(el, "title");
            String country  = getText(el, "country");
            String dateStr  = getText(el, "date");
            String timeStr  = getText(el, "time");
            String impact   = getText(el, "impact").toLowerCase();
            String forecast = getText(el, "forecast");
            String previous = getText(el, "previous");
            String actual   = getText(el, "actual");
            String revised  = getText(el, "revised");

            // pomiń Non-Economic
            if ("non-economic".equals(impact)) continue;

            // parsuj datę
            LocalDate date;
            try {
                date = LocalDate.parse(dateStr, inputDateFmt);
            } catch (Exception e) {
                log.warning("Nieprawidłowa data: " + dateStr);
                continue;
            }

            // parsuj czas i konwertuj Eastern → UTC (+5h zima, +4h lato)
            String timeUtc = parseTimeToUtc(timeStr, date);

            // mapuj impact
            String impactNorm = normalizeImpact(impact);

            CalendarEvent ev = new CalendarEvent();
            ev.source    = SOURCE;
            ev.datetime  = date.format(outputDateFmt) + " " + timeUtc;
            ev.cur       = country.trim();
            ev.impact    = impactNorm;

            // parsuj nazwę i wyciągnij period/timeframe
            ev.timeframe = ValueParser.extractTimeframe(title);
            ev.period    = ValueParser.extractPeriod(title);
            ev.event     = ValueParser.cleanEventName(title);

            // wartości
            ev.act  = cleanValue(actual);
            ev.fore = cleanValue(forecast);
            ev.pre  = cleanValue(previous);
            ev.rev  = cleanValue(revised);
            ev.type = ValueParser.getType(actual.isEmpty() ? previous : actual);

            // is_better — brak w XML, zostaje ""
            ev.is_better = "";

            // timeframe override jeśli All Day
            if ("Tentative".equalsIgnoreCase(timeStr) || "All Day".equalsIgnoreCase(timeStr)) {
                ev.timeframe = "day";
            }

            results.add(ev);
        }

        return results;
    }

    /**
     * Konwertuje czas Eastern Time → UTC.
     * Eastern: UTC-5 (zima) / UTC-4 (lato).
     */
    private String parseTimeToUtc(String timeStr, LocalDate date) {
        if (timeStr == null || timeStr.isBlank() ||
            "Tentative".equalsIgnoreCase(timeStr) ||
            "All Day".equalsIgnoreCase(timeStr)) {
            return "00:00";
        }

        try {
            // format: "8:30am", "12:00pm", "9:00am"
            timeStr = timeStr.trim().toLowerCase();
            boolean pm = timeStr.endsWith("pm");
            timeStr = timeStr.replace("am","").replace("pm","");
            String[] parts = timeStr.split(":");
            int hour = Integer.parseInt(parts[0]);
            int min  = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;

            if (pm && hour != 12) hour += 12;
            if (!pm && hour == 12) hour = 0;

            LocalTime lt = LocalTime.of(hour, min);
            LocalDateTime ldt = LocalDateTime.of(date, lt);

            // wykryj DST dla strefy Eastern
            ZoneId eastern = ZoneId.of("America/New_York");
            ZonedDateTime zdt = ZonedDateTime.of(ldt, eastern);
            ZonedDateTime utc = zdt.withZoneSameInstant(ZoneOffset.UTC);

            return String.format("%02d:%02d", utc.getHour(), utc.getMinute());
        } catch (Exception e) {
            log.warning("Nie można sparsować czasu: " + timeStr);
            return "00:00";
        }
    }

    private String normalizeImpact(String impact) {
        if (impact == null) return "";
        return switch (impact.toLowerCase()) {
            case "high"     -> "high";
            case "medium"   -> "medium";
            case "low"      -> "low";
            case "holiday"  -> "holiday";
            default         -> "";
        };
    }

    private String cleanValue(String raw) {
        String v = ValueParser.getValue(raw, 0);
        return (v == null || v.isEmpty()) ? "null" : v;
    }

    private String getText(Element el, String tag) {
        NodeList nl = el.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        Node n = nl.item(0);
        return n == null ? "" : (n.getTextContent() == null ? "" : n.getTextContent().trim());
    }
}
