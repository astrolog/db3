package stattrade.calendar.scraper;

import com.microsoft.playwright.*;
import stattrade.calendar.db.Database;
import stattrade.calendar.model.CalendarEvent;
import stattrade.calendar.util.ValueParser;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

/**
 * Scraper Investing.com — używa Playwright (strona renderowana JS).
 *
 * URL: https://www.investing.com/economic-calendar/
 * source = "IN"
 *
 * Tryby (mode):
 *   "now"  → od ostatniej daty w DB, kilka dni
 *   "next" → od ostatniej daty bez act, kilka dni
 *   brak   → od 2009-01-01 (backfill)
 */
public class InvestingScraper extends PlaywrightScraper {

    private static final String SOURCE = "IN";
    private static final String BASE_URL = "https://www.investing.com/economic-calendar/";
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DATE_FMT_US = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public InvestingScraper(Database db) {
        super(db);
    }

    public void run(String mode, boolean headless) {
        log.info("Investing.com start, mode=" + mode);
        initBrowser(headless);

        try {
            // ustal datę startową
            LocalDate startDate = resolveStartDate(mode);
            LocalDate endDate = LocalDate.now().plusDays(1);
            int maxIter = resolveMaxIter(mode, startDate, endDate);

            log.info("Start: " + startDate + " | iter max: " + maxIter);

            page.navigate(BASE_URL);
            page.waitForLoadState();

            // zamknij cookie banner
            clickIfPresent("#onetrust-accept-btn-handler");
            page.waitForTimeout(500);

            // zamknij popup jeśli jest
            clickIfPresent(".popupCloseIcon");
            page.waitForTimeout(300);

            // ustaw strefę UTC
            setTimezoneUtc();

            LocalDate current = startDate;
            int iter = 0;

            while (iter < maxIter && !current.isAfter(endDate)) {
                log.info("Przetwarzam dzień: " + current + " (iter " + iter + "/" + maxIter + ")");
                processDay(current, mode);
                current = current.plusDays(skipWeekend(current));
                iter++;
                page.waitForTimeout(1500);
            }

            db.runPostImport();
            log.info("Investing.com zakończony. Przetworzono " + iter + " dni.");

        } catch (Exception e) {
            log.severe("Błąd Investing: " + e.getMessage());
        } finally {
            close();
        }
    }

    private LocalDate resolveStartDate(String mode) {
        LocalDate now = LocalDate.now();
        return switch (mode) {
            case "now"  -> {
                LocalDate d = db.getLastDbDate(SOURCE);
                yield (d != null) ? d : now;
            }
            case "next" -> {
                LocalDate d = db.getLastDbDateNoAct(SOURCE);
                if (d != null) {
                    d = d.plusDays(1);
                    // pomiń weekend
                    if (d.getDayOfWeek().getValue() == 6) d = d.plusDays(2);
                    if (d.getDayOfWeek().getValue() == 7) d = d.plusDays(1);
                }
                yield (d != null) ? d : now;
            }
            default -> LocalDate.of(2009, 1, 1);
        };
    }

    private int resolveMaxIter(String mode, LocalDate start, LocalDate end) {
        long diffDays = java.time.temporal.ChronoUnit.DAYS.between(start, end);
        return switch (mode) {
            case "now"  -> (int) Math.min(diffDays + 3, 14);
            case "next" -> (int) Math.min(diffDays + 7, 30);
            default     -> 2000; // backfill
        };
    }

    /** Pomiń weekendy (zwraca ile dni dodać) */
    private int skipWeekend(LocalDate d) {
        return switch (d.plusDays(1).getDayOfWeek()) {
            case SATURDAY -> 3;
            case SUNDAY   -> 2;
            default       -> 1;
        };
    }

    private void setTimezoneUtc() {
        try {
            // kliknij selektor czasu
            Locator timePicker = page.locator("#economicCurrentTime").first();
            if (!timePicker.isVisible()) return;
            timePicker.click();
            page.waitForTimeout(400);

            // wybierz UTC (liTz55 = UTC+0)
            clickIfPresent("#liTz55");
            page.waitForTimeout(400);
            log.info("Ustawiono strefę UTC");
        } catch (Exception e) {
            log.warning("Nie można ustawić strefy UTC: " + e.getMessage());
        }
    }

    private void processDay(LocalDate date, String mode) {
        String dateStrUs = date.format(DATE_FMT_US);
        String dateStr   = date.format(DATE_FMT);

        try {
            // otwórz date picker
            Locator datePicker = page.locator("#datePickerToggleBtn").first();
            datePicker.click();
            page.waitForTimeout(400);

            // wpisz daty
            Locator startInput = page.locator("#startDate").first();
            startInput.fill("");
            startInput.type(dateStrUs);

            Locator endInput = page.locator("#endDate").first();
            endInput.fill("");
            endInput.type(dateStrUs);

            // zastosuj
            Locator applyBtn = page.locator("a:has-text('Apply')").first();
            applyBtn.click();
            page.waitForTimeout(1200);

            // pobierz dane
            List<CalendarEvent> events = extractEvents(date, dateStr);

            if (!events.isEmpty()) {
                db.deleteDate(date, SOURCE);
                for (CalendarEvent ev : events) {
                    db.saveEvent(ev);
                    log.info("IN zapisano: " + ev);
                }
            }

        } catch (Exception e) {
            log.warning("Błąd processDay " + date + ": " + e.getMessage());
        }
    }

    private List<CalendarEvent> extractEvents(LocalDate date, String dateStr) {
        List<CalendarEvent> events = new ArrayList<>();

        // wiersze kalendarza
        List<ElementHandle> rows = page.querySelectorAll("tr.js-event-item");
        if (rows.isEmpty()) {
            log.info("Brak wierszy dla " + dateStr);
            return events;
        }

        for (ElementHandle row : rows) {
            try {
                CalendarEvent ev = extractRow(row, dateStr);
                if (ev != null) events.add(ev);
            } catch (Exception e) {
                log.warning("Błąd parsowania wiersza: " + e.getMessage());
            }
        }

        return events;
    }

    private CalendarEvent extractRow(ElementHandle row, String dateStr) {
        // czas
        ElementHandle timeEl = row.querySelector("td.time");
        String timeText = timeEl != null ? timeEl.textContent().trim() : "00:00";
        if (timeText.isEmpty() || "All Day".equalsIgnoreCase(timeText)) timeText = "00:00";

        // waluta
        ElementHandle curEl = row.querySelector("td.flagCur");
        String cur = curEl != null ? curEl.textContent().trim().replace(" ", "") : "";

        // nazwa zdarzenia
        ElementHandle nameEl = row.querySelector("td.event a");
        if (nameEl == null) nameEl = row.querySelector("td.event");
        String rawEvent = nameEl != null ? nameEl.textContent().trim() : "";
        if (rawEvent.isEmpty()) return null;

        // impact — z atrybutu title obrazka
        ElementHandle impactEl = row.querySelector("td.sentiment");
        String impactHtml = impactEl != null ? impactEl.innerHTML() : "";
        String impact = parseImpact(impactHtml);

        // actual
        ElementHandle actEl = row.querySelector("td.act");
        String actText = actEl != null ? actEl.textContent().trim() : "";
        String actHtml = actEl != null ? actEl.innerHTML() : "";

        // forecast
        ElementHandle foreEl = row.querySelector("td.fore");
        String foreText = foreEl != null ? foreEl.textContent().trim() : "";

        // previous
        ElementHandle prevEl = row.querySelector("td.prev");
        String prevText = prevEl != null ? prevEl.textContent().trim() : "";
        String prevHtml = prevEl != null ? prevEl.innerHTML() : "";

        CalendarEvent ev = new CalendarEvent();
        ev.source   = SOURCE;
        ev.datetime = dateStr + " " + timeText;
        ev.cur      = cur;
        ev.impact   = impact;

        ev.timeframe = ValueParser.extractTimeframe(rawEvent);
        ev.period    = ValueParser.extractPeriod(rawEvent);
        ev.event     = ValueParser.cleanEventName(rawEvent);

        ev.act  = cleanVal(actText);
        ev.fore = cleanVal(foreText);
        ev.pre  = cleanVal(prevText);
        ev.type = ValueParser.getType(actText.isEmpty() ? prevText : actText);

        // is_better
        if (actHtml.contains("redFont") || actHtml.contains("worse"))      ev.is_better = "worse";
        else if (actHtml.contains("greenFont") || actHtml.contains("better")) ev.is_better = "better";
        else ev.is_better = "actual";

        // revised
        if (prevHtml.contains("Revised From")) {
            String rev = prevHtml.split("Revised From ")[1].split("<")[0];
            ev.rev = cleanVal(ValueParser.getValue(rev));
        }

        // timeframe override
        if ("00:00".equals(timeText)) ev.timeframe = "day";

        return ev;
    }

    private String parseImpact(String html) {
        if (html == null) return "";
        html = html.toLowerCase();
        if (html.contains("holiday")) return "holiday";
        // liczba wypełnionych byków = siła
        long bulls = countOccurrences(html, "grayFullBullishIcon");
        if (bulls >= 3) return "high";
        if (bulls == 2) return "medium";
        if (bulls == 1) return "low";
        return "";
    }

    private long countOccurrences(String text, String pattern) {
        int idx = 0, count = 0;
        while ((idx = text.indexOf(pattern, idx)) != -1) { count++; idx++; }
        return count;
    }

    private String cleanVal(String raw) {
        String v = ValueParser.getValue(raw, 0);
        return (v == null || v.isEmpty()) ? "null" : v;
    }
}
