package stattrade.calendar.db;

import stattrade.calendar.model.CalendarEvent;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

/**
 * Warstwa dostępu do MSSQL.
 * Odpowiednik funkcji SQL z load3.js (del_date, run_proc, get_last_db_date itp.)
 */
public class Database {

    private static final Logger log = Logger.getLogger(Database.class.getName());
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final String db;
    private Connection conn;

    public Database(String server, int port, String db, String user, String password) throws SQLException {
        this.db = db;
        String url = String.format(
            "jdbc:sqlserver://%s:%d;databaseName=%s;user=%s;password=%s;" +
            "encrypt=false;trustServerCertificate=true;" +
            "loginTimeout=30;socketTimeout=90000;",
            server, port, db, user, password
        );
        this.conn = DriverManager.getConnection(url);
        log.info("Połączono z bazą: " + db + " @ " + server);
    }

    /**
     * Pobiera datę ostatniego zdarzenia z aktualnymi danymi (act != null).
     * Odpowiednik get_last_db_date() z JS.
     */
    public LocalDate getLastDbDate(String source) {
        String sql = "SELECT TOP 1 CAST([datetime] AS DATE) AS d " +
                     "FROM [" + db + "].[dbo].[event3] WITH (NOLOCK) " +
                     "WHERE source = ? AND act IS NOT NULL AND [datetime] < GETUTCDATE() " +
                     "ORDER BY [datetime] DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, source);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Date d = rs.getDate("d");
                if (d != null) return d.toLocalDate();
            }
        } catch (SQLException e) {
            log.warning("getLastDbDate error: " + e.getMessage());
        }
        return null;
    }

    /**
     * Pobiera datę ostatniego zdarzenia (bez wymogu act).
     * Odpowiednik get_last_db_date_no_act() z JS.
     */
    public LocalDate getLastDbDateNoAct(String source) {
        String sql = "SELECT TOP 1 CAST([datetime] AS DATE) AS d " +
                     "FROM [" + db + "].[dbo].[event3] WITH (NOLOCK) " +
                     "WHERE source = ? " +
                     "ORDER BY [datetime] DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, source);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Date d = rs.getDate("d");
                if (d != null) return d.toLocalDate();
            }
        } catch (SQLException e) {
            log.warning("getLastDbDateNoAct error: " + e.getMessage());
        }
        return null;
    }

    /**
     * Usuwa zdarzenia z danego dnia i źródła przed ponownym zapisem.
     * Odpowiednik del_date() z JS.
     */
    public void deleteDate(LocalDate date, String source) {
        String sql = "DELETE FROM [" + db + "].[dbo].[event3] " +
                     "WHERE CAST([datetime] AS DATE) = ? AND source = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, date.format(DATE_FMT));
            ps.setString(2, source);
            int rows = ps.executeUpdate();
            log.info("Usunięto " + rows + " wierszy dla " + source + " / " + date);
        } catch (SQLException e) {
            log.warning("deleteDate error: " + e.getMessage());
        }
    }

    /**
     * Zapisuje zdarzenie przez procedurę sp_event3.
     * Odpowiednik run_proc() z JS.
     */
    public void saveEvent(CalendarEvent ev) {
        String sql = ev.toSqlExec(db);
        log.fine("SQL: " + sql);
        try (Statement st = conn.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            log.warning("saveEvent error: " + e.getMessage() + " | " + sql);
        }
    }

    /**
     * Uruchamia procedurę run_event3_imp po zakończeniu dnia.
     */
    public void runPostImport() {
        try (Statement st = conn.createStatement()) {
            st.execute("EXECUTE [dbo].[run_event3_imp]");
            log.info("run_event3_imp OK");
        } catch (SQLException e) {
            log.warning("runPostImport error: " + e.getMessage());
        }
    }

    /**
     * Zwraca liczbę minut do następnego zdarzenia w przyszłości.
     * Odpowiednik get_next_event_minutes() z JS.
     */
    public int getMinutesToNextEvent() {
        String sql = "SELECT DATEDIFF(minute, GETUTCDATE(), " +
                     "(SELECT MIN(datetime) FROM [" + db + "].[dbo].event3 " +
                     " WHERE datetime > GETUTCDATE())) AS t";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                int v = rs.getInt("t");
                return rs.wasNull() ? 9999 : v;
            }
        } catch (SQLException e) {
            log.warning("getMinutesToNextEvent error: " + e.getMessage());
        }
        return 9999;
    }

    public void close() {
        try { if (conn != null && !conn.isClosed()) conn.close(); }
        catch (SQLException ignored) {}
    }
}
