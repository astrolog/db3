package stattrade.calendar.util;

/**
 * Port funkcji get_value() i get_type() z load3.js.
 * Parsuje surowe stringi z kalendarzy do wartości numerycznych.
 */
public class ValueParser {

    private static final String[] SUFFIXES = {"K","M","B","T","k","m","b","t","%"};

    /**
     * Wyciąga wartość numeryczną ze stringa.
     * poz=0 → pierwsza wartość, poz=1 → po separatorze "|" lub "$"
     */
    public static String getValue(String str, int poz) {
        if (str == null || str.isBlank()) return "";
        str = str.trim();
        if (str.isEmpty()) return "";

        // separator pipe
        if (str.contains("|")) {
            String[] parts = str.split("\\|");
            if (poz < parts.length) str = parts[poz];
            else return "";
        }

        // separator dolar
        if (str.contains("$")) {
            String[] parts = str.split("\\$");
            if (poz == 1 && parts.length > 1) str = parts[1];
            else if (poz == 1) return "";
            else str = parts[0];
        } else if (poz == 1) {
            return "";
        }

        str = str.trim();
        if (str.isEmpty()) return "";

        // usuń sufiks jednostki
        String value = str;
        int len = str.length();
        if (len > 1) {
            String last = str.substring(len - 1);
            boolean hasSuffix = false;
            for (String s : SUFFIXES) {
                if (last.equals(s)) { hasSuffix = true; break; }
            }
            if (hasSuffix) {
                value = str.substring(0, len - 1);
            } else if (len == 6 && str.substring(4, 5).equals("|")) {
                value = str.substring(5);
            }
        }

        // usuń znak "<"
        if (value.startsWith("<")) value = value.substring(1);

        // usuń przecinki
        value = value.replace(",", "");

        // pattern YYYY-MM (data jako wartość) → weź tylko rok
        if (value.length() > 4 &&
            value.substring(1, 2).equals("-") &&
            value.substring(3, 4).equals("-")) {
            value = value.substring(0, 1);
        }

        // usuń wiodący znak niecifrowy (waluta itp.)
        if (!value.isEmpty() && !value.startsWith("-")) {
            char first = value.charAt(0);
            if (!Character.isDigit(first)) {
                value = value.substring(1);
            }
        }

        return isNumeric(value) ? value : "";
    }

    public static String getValue(String str) {
        return getValue(str, 0);
    }

    /**
     * Wyciąga sufiks jednostki (K/M/B/T/%) → type w bazie.
     */
    public static String getType(String str) {
        if (str == null || str.isBlank()) return "";
        str = str.trim();
        int len = str.length();
        if (len < 2) return "";

        String last = str.substring(len - 1);
        for (String s : new String[]{"K","M","B","T","%"}) {
            if (last.equals(s)) return last;
        }
        // specjalny case: 6 chars z | na poz 4 → typ "D"
        if (len == 6 && str.substring(4, 5).equals("|")) return "D";
        return "";
    }

    /**
     * Sprawdza czy string zawiera cyfrę (port isNumeric z JS).
     */
    public static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) return false;
        return str.matches(".*\\d+.*");
    }

    /**
     * Parsuje timeframe z nazwy zdarzenia (MoM/YoY/QoQ).
     */
    public static String extractTimeframe(String text) {
        if (text == null) return "";
        if (text.contains(" m/m") || text.contains("(MoM)")) return "MoM";
        if (text.contains(" y/y") || text.contains("(YoY)")) return "YoY";
        if (text.contains(" q/q") || text.contains("(QoQ)")) return "QoQ";
        return "";
    }

    /**
     * Usuwa sufiks timeframe/period z nazwy zdarzenia.
     */
    public static String cleanEventName(String text) {
        if (text == null) return "";
        text = text.replace(",", " ").replace("'", "");
        // usuń nawiasy timeframe
        for (String tf : new String[]{"(MoM)","(YoY)","(QoQ)"}) {
            text = text.replace(tf, "");
        }
        // usuń nawiasy period
        for (String p : new String[]{
            "(Jan)","(Feb)","(Mar)","(Apr)","(May)","(Jun)",
            "(Jul)","(Aug)","(Sep)","(Oct)","(Nov)","(Dec)",
            "(Q1)","(Q2)","(Q3)","(Q4)"
        }) {
            text = text.replace(p, "");
        }
        return text.trim();
    }

    /**
     * Wyciąga period (Jan..Dec, Q1..Q4) z nazwy zdarzenia.
     */
    public static String extractPeriod(String text) {
        if (text == null) return "";
        String[] periods = {
            "Jan","Feb","Mar","Apr","May","Jun",
            "Jul","Aug","Sep","Oct","Nov","Dec",
            "Q1","Q2","Q3","Q4"
        };
        for (String p : periods) {
            if (text.contains("(" + p + ")")) return p;
        }
        return "";
    }
}
