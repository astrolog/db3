# calendar-scraper

Scraper kalendarza ekonomicznego do bazy MSSQL.
Zastępuje `load3.js` (Protractor) — napisany w Java 17 + Maven.

## Źródła

| Źródło | Type | Metoda | Stabilność |
|--------|------|--------|------------|
| ForexFactory | FF | XML feed HTTP (bez przeglądarki) | Bardzo wysoka |
| Investing.com | IN | Playwright/Chromium | Wysoka |
| FXStreet | FX | Playwright/Chromium | Wysoka |
| Dukascopy | DC | **bez zmian** (load3.js) | — |

## Wymagania

- Java 17+
- Maven 3.8+
- MSSQL z bazą `db2` i procedurami `sp_event3`, `run_event3_imp`
- Internet (Playwright pobiera Chromium przy pierwszym uruchomieniu)

## Budowanie

```bash
mvn clean package -q
```

Tworzy: `target/calendar-scraper-1.0.0.jar`

## Uruchomienie

```bash
java -jar target/calendar-scraper-1.0.0.jar <src> [mode] [headless]
```

### Parametry

| Parametr | Wartości | Domyślnie |
|----------|----------|-----------|
| `src` | `forexfactory` (`ff`), `investing` (`in`), `fxstreet` (`fx`) | wymagany |
| `mode` | `now`, `next`, `today`, (brak) | brak = backfill |
| `headless` | `true`, `false` | `true` |

### Przykłady (odpowiedniki trybów z load3.js)

```bash
# forexfactory_now → bieżący + następny tydzień
java -jar calendar-scraper.jar forexfactory now

# forexfactory_next → tylko następny tydzień  
java -jar calendar-scraper.jar forexfactory next

# investing_now → od ostatniej daty w DB, kilka dni
java -jar calendar-scraper.jar investing now

# investing_next → od ostatniego dnia bez act
java -jar calendar-scraper.jar investing next

# fxstreet_now z widoczną przeglądarką (debug)
java -jar calendar-scraper.jar fxstreet now false

# pełny backfill investing od 2009
java -jar calendar-scraper.jar investing
```

## Konfiguracja bazy

Edytuj stałe w `Main.java`:

```java
private static final String DB_SERVER   = "127.0.0.1";
private static final int    DB_PORT     = 1433;
private static final String DB_NAME     = "db2";
private static final String DB_USER     = "sa";
private static final String DB_PASSWORD = "astrolog";
```

## Struktura projektu

```
src/main/java/stattrade/calendar/
├── Main.java                      ← punkt wejścia, CLI
├── model/
│   └── CalendarEvent.java         ← model zdarzenia (= kolumny event3)
├── db/
│   └── Database.java              ← SQL: save/delete/query
├── scraper/
│   ├── ForexFactoryScraper.java   ← FF: XML feed, bez przeglądarki
│   ├── PlaywrightScraper.java     ← baza dla IN i FX
│   ├── InvestingScraper.java      ← IN: Playwright
│   └── FxStreetScraper.java       ← FX: Playwright
└── util/
    └── ValueParser.java           ← port get_value/get_type z JS
```

## Pierwsze uruchomienie Playwright

Przy pierwszym starcie Playwright automatycznie pobiera Chromium (~170 MB):

```bash
java -jar calendar-scraper.jar investing now
# lub jawnie:
mvn exec:java -Dexec.mainClass="com.microsoft.playwright.CLI" -Dexec.args="install chromium"
```

## Windows Task Scheduler (zamiennik Protractora)

Przykładowe zadanie (inwestycje co godzinę):

```
Program: java
Argumenty: -jar C:\scraper\calendar-scraper.jar investing now
Katalog: C:\scraper
```

## Różnice względem load3.js

| load3.js | calendar-scraper |
|----------|-----------------|
| Protractor (porzucony) | Playwright for Java (aktywny) |
| `browser.driver.sleep()` | `page.waitForTimeout()` + `waitForSelector()` |
| Globalne zmienne | Obiekty Java, brak race condition |
| `browser.params.src` | argumenty CLI |
| Jeden plik 1965 linii | Moduły z separacją odpowiedzialności |
